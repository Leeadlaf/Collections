/*
 * File: HW3.java
 * Author: Kuni Scissum <kuni91@uab.edu
 * Assignment: HW3 - EE433 Fall 2013
 * Vers: 1.0.0 10/3/2013 kjs - initial coding
 * Credits: LocalLog package included based on David Green's code 
 *          <dgreen@uab.edu>
 * 
 */

import java.util.List;
import java.util.Iterator;
import java.sql.*;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
//import com.j256.ormlite.dao.ForeignCollection;
import com.j256.ormlite.jdbc.JdbcConnectionSource;
//import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.logger.LocalLog;
import com.j256.ormlite.table.TableUtils;
import com.mysql.jdbc.*;

/**
 *
 * @author Kuni J Scissum, <kuni91@uab.edu>
 */
public class InitializeEE433Database {

    private final static String DATABASE_URL = "jdbc:mysql://71.45.66.15:3306/ee433";
    private Dao<User, Integer> userDao;
    private Dao<Item, Integer> itemDao;
    private Dao<Collection, Integer> collectionDao;
    //private DriverManager drivers;

    public static void main(String[] args) throws Exception {
        (new InitializeEE433Database()).run(args);
    }

    private void run(String[] args) throws Exception {
        JdbcConnectionSource connectionSource = null;
        //drivers.getConnection(DATABASE_URL, "root", "Coll3ctor1");

        try {
            
            // create data source for the database
            connectionSource = new JdbcConnectionSource(DATABASE_URL,"collector", "Collectors");

            //setup database and DAOs. To create a new table, must uncomment.
            setupDatabase(connectionSource);

            //read and write
            //readWriteData();

            //System.out.println("\nWorks");
        } finally {
            if (connectionSource != null) {
                connectionSource.close();
            }
        }
    }

    private void setupDatabase(JdbcConnectionSource connectionSource) throws Exception {

        System.setProperty(LocalLog.LOCAL_LOG_FILE_PROPERTY, "log.log");
        
        // Create DAOs
        userDao = DaoManager.createDao(connectionSource, User.class);
        itemDao = DaoManager.createDao(connectionSource, Item.class);
        collectionDao = DaoManager.createDao(connectionSource, Collection.class);
        //Create tables
        TableUtils.createTableIfNotExists(connectionSource, User.class);
        TableUtils.createTableIfNotExists(connectionSource, Item.class);
        TableUtils.createTableIfNotExists(connectionSource, Collection.class);


    }

    private void readWriteData() throws Exception {

        /*
         * The following lines are commented out to prevent unnecessary increase
         * in table sizes. Creates a list of users, projects, and tasks.
         */
        User firstUser = new User("Kuni", "junk");
        userDao.create(firstUser);

        User secondUser = new User("Lee", "junk");
        userDao.create(secondUser);

        User thirdUser = new User("Jeremy", "junk");
        userDao.create(thirdUser);
        
        User fourthUser = new User("Ron", "junk");
        userDao.create(fourthUser);

       
      
        
    }
}
Collection$
===========

**Server Side**

*UAB EE433 - Team 2 - Android Phone App - Collection$*

### 12/07/2013 ~  KJS ~ Notes:

*	Ran into trouble trying to setup a server. 11:00 PM
	* I installed Apache Tomcat 7.0, MySQL, Eclipse ADT and Java EE on both my laptop and PC at home. 
	* It is simple enough to connect locally, but I tried connecting using web browser on phone and was unsuccessful.
	* Focusing on MySQL and Java Servlet for the remainder of the day.
	* Useful link for test cases: http://dev.mysql.com/doc/mysqltest/2.0/en/index.html

### 12/08/2013 ~ KJS ~ Notes:

* 	List of possible helpful URLs to look through:
	* http://wiki.apache.org/tomcat/FrontPage
	* http://www.tutorialspoint.com/servlets/servlets-database-access.htm
	* http://www.tutorialspoint.com/mysql/mysql-useful-functions.htm
	* http://www.tutorialspoint.com/mysql/mysql-count-function.htm
	* http://www.coreservlets.com/Apache-Tomcat-Tutorial/tomcat-7-with-eclipse.html#More-Info
	* http://dev.mysql.com/doc/refman/4.1/en/entering-queries.html
	* http://www.analysisandsolutions.com/code/mysql-tutorial.htm#tighten
	* http://www.mysql.com/products/
	* http://ormlite.com/data_types.shtml
	* http://stackoverflow.com/questions/17715449/how-to-get-data-from-web-service-in-android
*	Considering using ORMLite to link Collection and Items, similar to HW3. If it does not work, highly consider using a "Collections" and "UserID" property for items.
* Uploaded CollectionDatabaseTest project. Created to demonstrate Java connectivity to MySQL database. Only works when MySQL is installed locally; currently working on remote connection issue.
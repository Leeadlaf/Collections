Collections
-Index number
-name 
-owner
-number of items


Items:
-name
-index number
-collectionID number (association/link)
-date
-condition
-description
-forSale: Boolean

User
-userID  	(1,2,3,...)
-name		
-password ?
/*
 * File: AddItem.java
 * Author: Lee Adlaf <adlaf@uab.edu>
 * Vers: 1.0.0 12/10/2013 lwa - initial coding
 * 
 * Credits:
 */

package ee433.uab.edu.collections;

//TBD - write code / design screen to do add item
 
import android.os.Bundle;
import android.app.Activity;

 
public class AddItem extends Activity {
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item_screen);

    }

}

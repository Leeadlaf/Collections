/**
 * File: InfoExtractor.java
 * Author: Jeremy Box <jbox91a@uab.edu>
 * Vers: 1.0.0 12/06/2013 jtb - initial code
 * Vers: 1.0.0 12/06/2013 jtb - 
 *
 */

package ee433.uab.edu.collections;

// Q:	
// A: 				{date issue addressed: 12/dd/13	}
// Q:	
// A: 				{date issue addressed: 12/dd/13	}
// Q:
// A: 				{date issue addressed: 12/dd/13	} 

/* which imports are important to this class if any?*/
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
//import ee433.uab.edu.collections.R.id;
//import android.view.View.OnClickListener;
//import android.view.Menu;


/**
 * InfoExtractor interface for extracting the information in the UserInfoHolder object.
 * @author Jeremy T. Box <jbox91a@uab.edu>
 */


//public interface InfoExtractor {
//		void extractInfo(UserInfoHolder data);
//}
/** Automatically generated file. DO NOT MODIFY */
package ee433.uab.edu.collections;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}